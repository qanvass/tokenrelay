#!/usr/bin/env python3
"""
Universal Cost Savings Agent CLI for Top 6 LLMs and Top 6 AI IDEs.

Supports:
- LLM Providers: OpenAI, Anthropic, Google Gemini, DeepSeek, Mistral, Meta Llama/Ollama
- AI IDEs: Cursor, Windsurf, GitHub Copilot, Continue.dev, Cline, Claude Code
"""

import argparse
import json
import os
import re
import sys
from typing import Any, Dict, List, Tuple

# Comprehensive pricing reference per 1,000,000 tokens (USD)
PROVIDER_PRICING = {
    "openai-gpt-6-astra": {
        "provider": "OpenAI",
        "model": "GPT-6 Astra",
        "input": 10.00,
        "cached_input": 1.00,  # 90% discount
        "output": 50.00,
        "batch_discount": 0.50,
    },
    "openai-gpt-6.1-sol": {
        "provider": "OpenAI",
        "model": "GPT-6.1 Sol",
        "input": 2.00,
        "cached_input": 0.10,  # 95% discount
        "output": 10.00,
        "batch_discount": 0.50,
    },
    "anthropic-claude-3.5-sonnet": {
        "provider": "Anthropic",
        "model": "Claude 3.5 Sonnet",
        "input": 3.00,
        "cached_input": 0.30,  # 90% discount
        "output": 15.00,
        "batch_discount": 0.50,
    },
    "google-gemini-2.0-pro": {
        "provider": "Google",
        "model": "Gemini 2.0 Pro",
        "input": 1.25,
        "cached_input": 0.31,  # 75% context caching discount
        "output": 5.00,
        "batch_discount": 0.50,
    },
    "deepseek-v3": {
        "provider": "DeepSeek",
        "model": "DeepSeek V3",
        "input": 0.27,
        "cached_input": 0.07,  # ~75% disk cache discount
        "output": 1.10,
        "batch_discount": 0.50,
    },
    "mistral-codestral": {
        "provider": "Mistral AI",
        "model": "Codestral 25.08",
        "input": 0.30,
        "cached_input": 0.15,
        "output": 0.90,
        "batch_discount": 0.50,
    },
    "meta-llama-3.3-local": {
        "provider": "Meta / Local Ollama",
        "model": "Llama 3.3 70B",
        "input": 0.00,
        "cached_input": 0.00,
        "output": 0.00,
        "batch_discount": 0.00,
    },
}

CACHE_BUSTING_PATTERNS = [
    (re.compile(r"\b(20\d\d[-/]\d\d[-/]\d\d|\d\d:\d\d:\d\d)\b"), "Dynamic timestamp detected"),
    (re.compile(r"\b[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}\b", re.I), "Dynamic UUID detected"),
    (re.compile(r"\b(git commit|git hash|[0-9a-f]{40})\b", re.I), "Volatile git hash detected"),
]


def compare_all_providers(input_tokens: int, output_tokens: int, requests: int = 1) -> List[Dict[str, Any]]:
    """Compare projected costs across all top providers."""
    results = []
    total_in_m = (input_tokens * requests) / 1_000_000
    total_out_m = (output_tokens * requests) / 1_000_000

    for key, spec in PROVIDER_PRICING.items():
        inp_rate = spec["input"]
        cached_inp_rate = spec["cached_input"]
        out_rate = spec["output"]
        batch_disc = spec["batch_discount"]

        standard_cost = (total_in_m * inp_rate) + (total_out_m * out_rate)

        # 1st request miss + remaining hits (or 80% cached if 1 request)
        if requests > 1:
            cached_in_cost = (
                ((input_tokens / 1_000_000) * inp_rate)
                + (((input_tokens * (requests - 1)) / 1_000_000) * cached_inp_rate)
            )
        else:
            cached_in_cost = (total_in_m * 0.2 * inp_rate) + (total_in_m * 0.8 * cached_inp_rate)

        cached_cost = cached_in_cost + (total_out_m * out_rate)
        batch_cost = standard_cost * (1.0 - batch_disc)

        results.append({
            "key": key,
            "provider": spec["provider"],
            "model": spec["model"],
            "standard_cost": round(standard_cost, 4),
            "cached_cost": round(cached_cost, 4),
            "batch_cost": round(batch_cost, 4),
            "savings_caching_pct": round(((standard_cost - cached_cost) / standard_cost) * 100, 1) if standard_cost > 0 else 0,
        })
    return results


def audit_ide_file(filepath: str) -> Dict[str, Any]:
    """Audit an IDE rules file (.cursorrules, .windsurfrules, CLAUDE.md, etc.) for token waste."""
    if not os.path.exists(filepath):
        return {"error": f"File not found: {filepath}"}

    with open(filepath, "r", encoding="utf-8", errors="ignore") as f:
        content = f.read()

    lines = content.splitlines()
    word_count = len(content.split())
    char_count = len(content)
    estimated_tokens = int(char_count / 4)

    warnings = []

    # Check for cache-busting patterns
    for pattern, label in CACHE_BUSTING_PATTERNS:
        matches = pattern.findall(content)
        if matches:
            warnings.append(f"{label}: found {len(matches)} instance(s) (e.g. '{matches[0]}'). Remove to prevent cache misses.")

    # Check for token bloat (> 400 words is heavy for an IDE rule that prepends every turn)
    if word_count > 400:
        warnings.append(
            f"Rule file is {word_count} words (~{estimated_tokens} tokens). IDE rules prepend EVERY prompt turn. Recommend condensing to under 250 words."
        )

    # Check for redundant code dumps
    if "```" in content and content.count("```") > 4:
        warnings.append("Multiple raw code blocks found. Move reference code to workspace files rather than static IDE rules.")

    return {
        "file": filepath,
        "lines": len(lines),
        "word_count": word_count,
        "estimated_tokens_per_turn": estimated_tokens,
        "status": "NEEDS_OPTIMIZATION" if warnings else "OPTIMAL",
        "warnings": warnings,
    }


def batchify_requests(input_file: str, output_file: str, provider: str = "openai") -> int:
    """Format an array of requests into provider-specific Batch API format."""
    with open(input_file, "r", encoding="utf-8") as f:
        data = json.load(f)

    requests = data if isinstance(data, list) else [data]
    lines = []

    for idx, req in enumerate(requests):
        req_id = req.get("custom_id", f"req-{idx+1}")
        messages = req.get("messages", [])
        model = req.get("model", "gpt-6.1-sol" if provider == "openai" else "claude-3-5-sonnet-20241022")

        if provider == "anthropic":
            record = {
                "custom_id": req_id,
                "params": {
                    "model": model,
                    "max_tokens": req.get("max_tokens", 4096),
                    "messages": messages,
                },
            }
        else:  # openai / generic
            record = {
                "custom_id": req_id,
                "method": "POST",
                "url": "/v1/chat/completions",
                "body": {
                    "model": model,
                    "messages": messages,
                    "temperature": req.get("temperature", 0.7),
                },
            }
        lines.append(json.dumps(record))

    with open(output_file, "w", encoding="utf-8") as f:
        for line in lines:
            f.write(line + "\n")

    return len(lines)


def main():
    parser = argparse.ArgumentParser(description="Universal Cost Savings Agent CLI (Top 6 LLMs & IDEs)")
    subparsers = parser.add_subparsers(dest="command", required=True)

    # Subcommand: compare
    comp_parser = subparsers.add_parser("compare", help="Compare costs across Top 6 LLM providers")
    comp_parser.add_argument("--input-tokens", type=int, default=500000, help="Input tokens per request")
    comp_parser.add_argument("--output-tokens", type=int, default=50000, help="Output tokens per request")
    comp_parser.add_argument("--requests", type=int, default=20, help="Number of iterative coding turns")

    # Subcommand: audit-ide
    audit_parser = subparsers.add_parser("audit-ide", help="Audit an IDE rules file (.cursorrules, CLAUDE.md, etc.)")
    audit_parser.add_argument("--file", type=str, required=True, help="Path to rules file")

    # Subcommand: batchify
    batch_parser = subparsers.add_parser("batchify", help="Convert requests into Batch API format")
    batch_parser.add_argument("--input", type=str, required=True, help="Input JSON file")
    batch_parser.add_argument("--output", type=str, required=True, help="Output JSONL file")
    batch_parser.add_argument("--provider", type=str, default="openai", choices=["openai", "anthropic", "mistral"])

    args = parser.parse_args()

    if args.command == "compare":
        results = compare_all_providers(args.input_tokens, args.output_tokens, args.requests)
        print("\n" + "=" * 90)
        print(f"COST COMPARISON: {args.requests} requests x ({args.input_tokens:,} in / {args.output_tokens:,} out)")
        print("=" * 90)
        print(f"{'Provider':<16} {'Model':<22} {'Standard':<12} {'Cached':<12} {'Batch (50%)':<12} {'Cache Cut':<10}")
        print("-" * 90)
        for r in results:
            print(
                f"{r['provider']:<16} {r['model']:<22} "
                f"${r['standard_cost']:>8.2f}    "
                f"${r['cached_cost']:>8.2f}    "
                f"${r['batch_cost']:>8.2f}    "
                f"{r['savings_caching_pct']:>6.1f}%"
            )
        print("=" * 90 + "\n")

    elif args.command == "audit-ide":
        res = audit_ide_file(args.file)
        print(json.dumps(res, indent=2))

    elif args.command == "batchify":
        count = batchify_requests(args.input, args.output, args.provider)
        print(f"Successfully generated {count} batch requests in {args.output} (Provider: {args.provider})")


if __name__ == "__main__":
    main()
