# Universal Cost Savings Agent & Multi-Model Skill

A production-ready skill and automated **Cost Savings Agent** engineered to audit and slash developer token spend across the **Top 6 LLM Providers** and the **Top 6 AI Coding IDEs**.

---

## Supported Ecosystem

### Top 6 LLM Providers
| Provider | Flagship & Workhorse Models | Major Cost Levers |
| :--- | :--- | :--- |
| **OpenAI** | GPT-6 Astra, GPT-6.1 Sol, GPT-6.1 Terra | 90% Prompt Caching, 50% Batch API, Startup Credits |
| **Anthropic** | Claude 3.7 / 3.5 Sonnet, Claude 3.5 Haiku | 90% Prompt Caching (5m/1h TTL), 50% Batch API, Architect/Editor split |
| **Google** | Gemini 2.0 Pro, Gemini 2.0 Flash | 75–95% Context Caching, 50% Batch API, Free Tier (AI Studio) |
| **DeepSeek** | DeepSeek V3, DeepSeek R1 | Disk-level Context Caching (up to 90%), Off-peak discounts |
| **Mistral AI** | Codestral 25.08, Mistral Large 3 | Dedicated coding endpoint pricing ($0.30/1M in), 50% Batch API |
| **Meta / Open Weights** | Llama 3.3 70B, Qwen 2.5 Coder (via Ollama / Groq) | $0 Local Inference via Ollama, Sub-cent cloud LPU inference |

### Top 6 AI IDEs & Environments
1. **Cursor** (`.cursorrules` & `.cursor/rules` audit, prompt caching keys, model switcher)
2. **Windsurf** (`.windsurfrules` stabilization, Cascade index bounding)
3. **GitHub Copilot** (`.copilotignore` asset stripping, workspace index control)
4. **Continue.dev** (`config.json` model tiering: local autocomplete + cloud chat)
5. **Cline / Roo Code** (Explicit prompt cache breakpoints, token expenditure tracking per step)
6. **Claude Code / Aider** (`CLAUDE.md` prefix stability, `/compact` context compression)

---

## Repository Structure

```
openai-cost-optimization/
├── SKILL.md                          # Skill definition and agent system instructions
├── README.md                         # Project documentation and CLI usage guide
├── .cursorrules                      # IDE optimization rules for Cursor
├── .windsurfrules                    # IDE optimization rules for Windsurf
├── CLAUDE.md                         # Context & cost rules for Claude Code / Claude
├── scripts/
│   └── cost_savings_agent.py         # Autonomous CLI Cost Savings Agent (Python stdlib)
└── references/
    └── pricing_matrix.json           # Live token rates, discount levers, and IDE specs
```

---

## Developing with an AI IDE

When you open this repository in an AI IDE (such as **Cursor**, **Windsurf**, **Continue.dev**, or **VS Code with Claude Code/Copilot**):
- The bundled `.cursorrules`, `.windsurfrules`, and `CLAUDE.md` automatically instruct the IDE agent to:
  1. Keep all scripts strictly standard library Python 3 (zero external dependencies).
  2. Maintain verifiable pricing calculations across all 6 model families.
  3. Avoid adding token bloat or dynamic cache-busting tokens into rules files.

### Contributing & Extending via IDE
You can prompt your IDE with instructions like:
- *"Add support for Amazon Bedrock Claude endpoints to `cost_savings_agent.py` and `pricing_matrix.json`."*
- *"Implement a scanner in `audit-ide` that checks for duplicate rules across `.cursorrules` and `.clinerules`."*
- *"Write unit tests under `tests/test_agent.py` validating the cost calculations."*

---

## CLI Usage

No external dependencies are required. Runs on any standard Python 3.8+ installation.

### 1. Compare Costs Across All 6 Providers
Compare projected spend across standard, prompt-cached, and Batch API executions:
```bash
python3 scripts/cost_savings_agent.py compare \
  --input-tokens 500000 \
  --output-tokens 50000 \
  --requests 20
```

### 2. Audit an IDE Rule File
Check your IDE configuration file (`.cursorrules`, `CLAUDE.md`, `.windsurfrules`) for cache-busting dynamic tokens and token bloat:
```bash
python3 scripts/cost_savings_agent.py audit-ide --file .cursorrules
```

### 3. Generate 50% Discounted Batch API Payloads
Format non-interactive tasks into provider-specific Batch API JSONL:
```bash
python3 scripts/cost_savings_agent.py batchify \
  --input requests.json \
  --output batch_job.jsonl \
  --provider openai
```
*(Supports `--provider openai`, `--provider anthropic`, or `--provider mistral`)*

---

## License

MIT License. Free to use, modify, and distribute.
