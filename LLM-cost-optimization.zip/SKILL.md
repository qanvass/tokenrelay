---
name: openai-cost-optimization
description: Deploys a universal Cost Savings Agent to audit token spend, enforce 50-90% prompt caching, format batch workloads, and optimize the Top 6 LLMs (OpenAI, Anthropic, Gemini, DeepSeek, Mistral, Llama) across the Top 6 AI IDEs (Cursor, Windsurf, GitHub Copilot, Continue.dev, Cline, Claude Code). Use when users ask to reduce AI coding costs, audit IDE tokens, or optimize multi-provider LLM budgets.
---
# openai-cost-optimization

A universal Cost Savings Agent and skill engineered to minimize LLM inference costs and developer token expenditure across the Top 6 frontier LLM providers and the Top 6 AI coding IDEs and autonomous agent environments.

## When to Use

- When configuring or auditing AI coding IDEs (Cursor, Windsurf, GitHub Copilot, Continue.dev, Cline, Claude Code) to stop token waste.

- When optimizing prompt payloads for automatic prefix caching across OpenAI, Anthropic, Google Gemini, and DeepSeek.

- When routing non-realtime coding and refactoring tasks through 50% discounted Batch APIs (OpenAI, Anthropic, Gemini, Mistral).

- When establishing a multi-tier model strategy (flagship reasoning vs. fast workhorses vs. free local models).

- When benchmarking projected development costs across different AI providers and coding extensions.

## Supported Ecosystem Matrix

### Top 6 LLM Providers & Cost Levers

1. OpenAI (GPT-6 Astra, GPT-6.1 Sol, GPT-6.1 Terra):
   - 90% prompt caching discount ($1.00/1M on Astra, $0.10/1M on Sol).
   - 50% Batch API discount via /v1/batches.
   - Partner VC credits ($1,000 to $100,000+) via OpenAI for Startups.

2. Anthropic (Claude 3.7 / 3.5 Sonnet, Claude 3.5 Haiku):
   - 90% prompt caching discount on stable 5-minute/1-hour prefixes.
   - 50% Batch processing discount via Messages Batch API.
   - Dual-model architect/editor workflows.

3. Google Gemini (Gemini 2.5 / 2.0 Pro & Flash):
   - 75% to 95% context caching discount for prompts over 32k tokens.
   - 50% Batch API discount.
   - Generous daily replenishing free tier on Google AI Studio for prototyping.

4. DeepSeek (DeepSeek V3, DeepSeek R1, DeepSeek Coder):
   - Automatic disk-level context caching with up to 90% input discounts.
   - Off-peak 50% pricing reductions.
   - Lowest baseline frontier inference rates in the industry ($0.14 to $0.29/1M).

5. Mistral AI (Codestral, Mistral Large 3):
   - 50% Batch API discount on code generation endpoints.
   - High-throughput dedicated code completion models (Codestral at $0.30/1M input).

6. Meta Llama & Open Weights (Llama 3.3, Qwen 2.5 Coder via Ollama / Groq / vLLM):
   - $0 inference cost for local hardware setups (Ollama / vLLM).
   - Sub-cent rates on high-speed inference engines (Groq, Together AI, Cerebras).

### Top 6 AI IDEs & Agent Levers

1. Cursor:
   - Audit .cursorrules and .cursor/rules to avoid bloated per-turn overhead.
   - Configure custom API keys with prompt-caching enabled providers.
   - Use smart model switching between chat exploration and multi-file editing.

2. Windsurf (Codeium):
   - Stabilize .windsurfrules to prevent cache invalidation in Cascade flows.
   - Restrict auto-indexing boundaries to relevant project directories.

3. GitHub Copilot (VS Code / JetBrains):
   - Maximize workspace context indexing efficiency with scoped ignore files (.copilotignore).
   - Select cost-optimal backend models for Copilot Chat.

4. Continue.dev:
   - Configure config.json for automated tiering: local Ollama for Tab autocomplete, DeepSeek or Sol for chat, and Astra or Sonnet for complex diffs.
   - Enable native prompt caching flags across custom endpoints.

5. Cline / Roo Code:
   - Enable explicit prompt caching breakpoints on Claude and OpenAI.
   - Monitor real-time token expenditure per task step with automatic context pruning.

6. Claude Code / Aider:
   - Maintain a stable, lean CLAUDE.md (avoid editing mid-session to preserve cache).
   - Use architect/editor mode to isolate planning tokens from code writing tokens.
   - Run /compact to compress conversation histories before starting new subtasks.

## Cost Savings Agent Workflow

When invoked, the Cost Savings Agent executes a 4-step optimization:

### 1. IDE Configuration Audit

- Scan workspace rules files (.cursorrules, .windsurfrules, CLAUDE.md, .copilotignore).
- Flag cache-busting entries: Remove dynamic dates, build hashes, or user-specific paths from static rule files.
- Prune rule token bloat: Compress verbose instructions into concise bulleted guidelines.

### 2. Prefix Stabilization

- Order instructions: Static project architecture -> Library specs -> Dynamic user request.
- Ensure that the initial 1,024+ tokens remain identical across turns to guarantee cache hits.

### 3. Batch Workload Routing

- Isolate offline jobs: Extract test generation, bulk docstring creation, and migration scripts.
- Package into standard Batch API JSONL formats for 50% cost reductions across OpenAI, Anthropic, Gemini, and Mistral.

### 4. Cross-Provider Cost Estimation

- Project monthly development spend across providers using `scripts/cost_savings_agent.py estimate`.
- Output recommended routing configurations matching the developer budget.

## Bundled CLI Tooling

- Audit an IDE rules file: `python3 scripts/cost_savings_agent.py audit-ide --file .cursorrules`
- Compare costs across all 6 providers: `python3 scripts/cost_savings_agent.py compare --input-tokens 500000 --output-tokens 50000 --requests 20`
- Generate Batch API payloads: `python3 scripts/cost_savings_agent.py batchify --input tasks.json --provider anthropic --output batch.jsonl`

## Gotchas

- Cache TTL expirations: Anthropic caches hold for 5 minutes (or 1 hour extended); OpenAI caches refresh on active sessions. Avoid prolonged idle periods mid-task.
- IDE rule bloat: Storing thousands of tokens of static documentation in IDE rules increases input cost on every single keystroke or chat turn. Keep rules under 300 words.
